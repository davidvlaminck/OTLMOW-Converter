from __future__ import annotations

import inspect
import warnings
from asyncio import sleep
from datetime import time, datetime, date
from pathlib import Path
from typing import Generator

from otlmow_model.OtlmowModel.BaseClasses.OTLObject import OTLObject, OTLAttribuut, dynamic_create_instance_from_uri, \
    get_attribute_by_name
from otlmow_model.OtlmowModel.Exceptions.CouldNotConvertToCorrectTypeError import CouldNotConvertToCorrectTypeError
from otlmow_model.OtlmowModel.Exceptions.NonStandardAttributeWarning import NonStandardAttributeWarning
from otlmow_model.OtlmowModel.Exceptions.RemovedOptionError import RemovedOptionError
from otlmow_model.OtlmowModel.Exceptions.UnionTypeError import UnionTypeError
from otlmow_model.OtlmowModel.Exceptions.WrongGeometryTypeError import WrongGeometryTypeError

from otlmow_converter.DotnotationDict import DotnotationDict
from otlmow_converter.DotnotationHelper import DotnotationHelper
from otlmow_converter.Exceptions.DotnotationListOfListError import DotnotationListOfListError
from otlmow_converter.Exceptions.MissingHeaderError import MissingHeaderError
from otlmow_converter.Exceptions.MultipleAttributeError import MultipleAttributeError
from otlmow_converter.Exceptions.OTLAttributeError import OTLAttributeError
from otlmow_converter.SettingsManager import load_settings, GlobalVariables

load_settings()

SEPARATOR = GlobalVariables.settings['formats']['OTLMOW']['dotnotation']['separator']
CARDINALITY_SEPARATOR = GlobalVariables.settings['formats']['OTLMOW']['dotnotation']['cardinality_separator']
CARDINALITY_INDICATOR = GlobalVariables.settings['formats']['OTLMOW']['dotnotation']['cardinality_indicator']
WAARDE_SHORTCUT = GlobalVariables.settings['formats']['OTLMOW']['dotnotation']['waarde_shortcut']


class DotnotationDictConverter:
    def __init__(self, separator: str = SEPARATOR, cardinality_separator: str = CARDINALITY_SEPARATOR,
                 cardinality_indicator: str = CARDINALITY_INDICATOR, waarde_shortcut: bool = WAARDE_SHORTCUT):
        self.separator: str = separator
        self.cardinality_separator: str = cardinality_separator
        self.cardinality_indicator: str = cardinality_indicator
        self.waarde_shortcut: bool = waarde_shortcut

    def to_dict_instance(self, otl_object: OTLObject, waarde_shortcut: bool = WAARDE_SHORTCUT,
                         separator: str = SEPARATOR, cardinality_indicator: str = CARDINALITY_SEPARATOR,
                         cardinality_separator: str = CARDINALITY_INDICATOR,
                         cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
                         warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False
                         ) -> DotnotationDict:
        if self.separator is not None:
            separator = self.separator
        if self.waarde_shortcut is not None:
            waarde_shortcut = self.waarde_shortcut
        if self.cardinality_indicator is not None:
            cardinality_indicator = self.cardinality_indicator
        if self.cardinality_separator is not None:
            cardinality_separator = self.cardinality_separator

        return self.to_dict(otl_object=otl_object, waarde_shortcut=waarde_shortcut, separator=separator,
                            cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                            allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                            warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                            cast_list=cast_list, cast_datetime=cast_datetime)

    async def to_dict_instance_async(self, otl_object: OTLObject, waarde_shortcut: bool = WAARDE_SHORTCUT,
                         separator: str = SEPARATOR, cardinality_indicator: str = CARDINALITY_SEPARATOR,
                         cardinality_separator: str = CARDINALITY_INDICATOR,
                         cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
                         warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False
                         ) -> DotnotationDict:
        if self.separator is not None:
            separator = self.separator
        if self.waarde_shortcut is not None:
            waarde_shortcut = self.waarde_shortcut
        if self.cardinality_indicator is not None:
            cardinality_indicator = self.cardinality_indicator
        if self.cardinality_separator is not None:
            cardinality_separator = self.cardinality_separator

        return await self.to_dict(otl_object=otl_object, waarde_shortcut=waarde_shortcut, separator=separator,
                            cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                            allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                            warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                            cast_list=cast_list, cast_datetime=cast_datetime)

    @classmethod
    def to_dict(cls, otl_object: OTLObject, waarde_shortcut: bool = WAARDE_SHORTCUT, separator: str = SEPARATOR,
                cardinality_indicator: str = CARDINALITY_INDICATOR, cardinality_separator: str = CARDINALITY_SEPARATOR,
                cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
                warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False,
                collect_native_types: bool = False) -> DotnotationDict:
        type_uri = getattr(otl_object, 'typeURI', None)
        if type_uri is None:
            raise ValueError('typeURI is None. The object must have an attribute typeURI.')

        ddict = {}

        if collect_native_types:
            native_type_dict = {}
            for dot_key, value, native_type in cls._iterate_over_attributes_and_values_by_dotnotation(
                object_or_attribute=otl_object, waarde_shortcut=waarde_shortcut, separator=separator,
                cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                cast_list=cast_list, cast_datetime=cast_datetime, collect_native_types=collect_native_types):
                ddict[dot_key] = value
                if native_type is not None:
                    native_type_dict[dot_key] = native_type
            if native_type_dict:
                ddict['_native_type_dict'] = native_type_dict
        else:
            for dot_key, value in cls._iterate_over_attributes_and_values_by_dotnotation(
                object_or_attribute=otl_object, waarde_shortcut=waarde_shortcut, separator=separator,
                cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                cast_list=cast_list, cast_datetime=cast_datetime):
                ddict[dot_key] = value

        ddict['typeURI'] = type_uri

        return DotnotationDict(ddict)

    @classmethod
    async def to_dict_async(
            cls, otl_object: OTLObject, waarde_shortcut: bool = WAARDE_SHORTCUT, separator: str = SEPARATOR,
            cardinality_indicator: str = CARDINALITY_INDICATOR, cardinality_separator: str = CARDINALITY_SEPARATOR,
            cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
            warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False
            ) -> DotnotationDict:
        type_uri = getattr(otl_object, 'typeURI', None)
        if type_uri is None:
            raise ValueError('typeURI is None. The object must have an attribute typeURI.')

        await sleep(0)
        d = DotnotationDict(cls._iterate_over_attributes_and_values_by_dotnotation(
            object_or_attribute=otl_object, waarde_shortcut=waarde_shortcut, separator=separator,
            cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
            allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
            warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
            cast_list=cast_list, cast_datetime=cast_datetime))
        d['typeURI'] = type_uri
        return d

    @classmethod
    def _iterate_over_attributes_and_values_by_dotnotation(
        cls, object_or_attribute: OTLObject | OTLAttribuut,
        waarde_shortcut: bool = WAARDE_SHORTCUT,
        separator: str = SEPARATOR,
        cardinality_indicator: str = CARDINALITY_INDICATOR,
        cardinality_separator: str = CARDINALITY_SEPARATOR,
        allow_non_otl_conform_attributes: bool = True,
        warn_for_non_otl_conform_attributes: bool = True,
        cast_list: bool = False,
        cast_datetime: bool = False,
        collect_native_types: bool = False
    ):
        for attr_key, attribute in vars(object_or_attribute).items():
            if attr_key in {'_parent', '_valid_relations', '_geometry_types',
                            '_is_waarden_object', '_is_union_waarden_object'}:
                continue
            if not getattr(attribute, 'is_otl_attribute', False):
                yield from cls._yield_non_conform(attr_key, attribute, object_or_attribute,
                                                  allow_non_otl_conform_attributes, warn_for_non_otl_conform_attributes,
                                                  collect_native_types)
                continue

            if attribute.waarde is None:
                yield from cls._yield_none_value(attribute, waarde_shortcut, separator, cardinality_indicator,
                                                 collect_native_types)
                continue

            if attribute.field.waardeObject is None:
                yield from cls._yield_simple_field(attribute, waarde_shortcut, separator, cardinality_indicator,
                                                   cardinality_separator, cast_list, cast_datetime, collect_native_types)
                continue

            if attribute.kardinaliteit_max != '1':
                yield from cls._yield_list_field(attribute, waarde_shortcut, separator, cardinality_indicator,
                                                 cardinality_separator, allow_non_otl_conform_attributes,
                                                 warn_for_non_otl_conform_attributes, cast_list, cast_datetime,
                                                 collect_native_types)
                continue

            yield from cls._iterate_over_attributes_and_values_by_dotnotation(
                object_or_attribute=attribute.waarde, waarde_shortcut=waarde_shortcut, separator=separator,
                cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                cast_list=cast_list, cast_datetime=cast_datetime, collect_native_types=collect_native_types
            )

    @classmethod
    def _yield_non_conform(cls, attr_key, attribute, object_or_attribute,
                           allow_non_otl_conform_attributes, warn_for_non_otl_conform_attributes, collect_native_types):
        for k, v in cls.handle_non_conform_attribute(
                allow_non_otl_conform_attributes, attr_key, attribute,
                object_or_attribute, warn_for_non_otl_conform_attributes):
            if collect_native_types:
                yield k, v, None
            else:
                yield k, v

    @classmethod
    def _yield_none_value(cls, attribute, waarde_shortcut, separator, cardinality_indicator, collect_native_types):
        field = attribute.field
        kard_max = attribute.kardinaliteit_max
        mark_to_be_cleared = attribute.mark_to_be_cleared
        native_type = getattr(field, 'native_type', None) if collect_native_types else None
        if not mark_to_be_cleared:
            return
        dotnotation = DotnotationHelper.get_dotnotation(
            attribute, waarde_shortcut=waarde_shortcut, separator=separator,
            cardinality_indicator=cardinality_indicator)
        val = '88888888' if kard_max != '1' else field.clearing_value
        if collect_native_types:
            yield dotnotation, val, native_type
        else:
            yield dotnotation, val

    @classmethod
    def _yield_simple_field(cls, attribute, waarde_shortcut, separator, cardinality_indicator,
                           cardinality_separator, cast_list, cast_datetime, collect_native_types):
        field = attribute.field
        kard_max = attribute.kardinaliteit_max
        waarde = attribute.waarde
        mark_to_be_cleared = attribute.mark_to_be_cleared
        native_type = getattr(field, 'native_type', None) if collect_native_types else None
        dotnotation = DotnotationHelper.get_dotnotation(
            attribute, waarde_shortcut=waarde_shortcut, separator=separator,
            cardinality_indicator=cardinality_indicator)
        if dotnotation.count(cardinality_indicator) > 1:
            raise DotnotationListOfListError(f'Can not use dotnotation for lists of lists. '
                                             f'Dotnotation: {dotnotation}')
        if mark_to_be_cleared:
            if collect_native_types:
                yield dotnotation, field.clearing_value, native_type
            else:
                yield dotnotation, field.clearing_value

        if cast_list and kard_max != '1':
            val = cardinality_separator.join(str(a) for a in waarde)
            if collect_native_types:
                yield dotnotation, val, native_type
            else:
                yield dotnotation, val
        elif cast_datetime:
            val = field.value_default(waarde)
            if collect_native_types:
                yield dotnotation, val, native_type
            else:
                yield dotnotation, val
        elif collect_native_types:
            yield dotnotation, waarde, native_type
        else:
            yield dotnotation, waarde

    @classmethod
    def _yield_list_field(cls, attribute, waarde_shortcut, separator, cardinality_indicator,
                          cardinality_separator, allow_non_otl_conform_attributes,
                          warn_for_non_otl_conform_attributes, cast_list, cast_datetime, collect_native_types):
        waarde = attribute.waarde
        combined_dict = {}
        native_types = {}
        for index, lijst_item in enumerate(waarde):
            for result in cls._iterate_over_attributes_and_values_by_dotnotation(
                object_or_attribute=lijst_item, waarde_shortcut=waarde_shortcut, separator=separator,
                cardinality_indicator=cardinality_indicator, cardinality_separator=cardinality_separator,
                allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes,
                cast_list=cast_list, cast_datetime=cast_datetime,
                collect_native_types=collect_native_types
            ):
                if collect_native_types:
                    k1, v1, nt = result
                else:
                    k1, v1 = result
                    nt = None
                if k1 not in combined_dict:
                    combined_dict[k1] = [None] * index
                combined_dict[k1].append(v1)
                if collect_native_types and nt is not None:
                    native_types[k1] = nt
            for lijst in combined_dict.values():
                if len(lijst) < index + 1:
                    lijst.append(None)
        if cast_list:
            for k, v in combined_dict.items():
                val = cardinality_separator.join(str(a) for a in v)
                if collect_native_types:
                    yield k, val, native_types.get(k)
                else:
                    yield k, val
        elif collect_native_types:
            for k, v in combined_dict.items():
                yield k, v, native_types.get(k)
        else:
            yield from combined_dict.items()

    @staticmethod
    def handle_non_conform_attribute(allow_non_otl_conform_attributes: bool, attr_key: str, attribute: object,
        object_or_attribute: object, warn_for_non_otl_conform_attributes: bool
                                     ) -> Generator[tuple[str, object], None, None]:
        if attr_key.startswith('_'):
            raise ValueError(
                f'{attr_key} is a non standardized attribute of {object_or_attribute.__class__.__name__}. '
                f'While this is supported, the key can not start with "_".')
        if not allow_non_otl_conform_attributes:
            raise ValueError(
                f'{attr_key} is a non standardized attribute of {object_or_attribute.__class__.__name__}. '
                f'If you want to allow this, set allow_non_otl_conform_attributes to True.')
        if warn_for_non_otl_conform_attributes:
            warnings.warn(
                message=f'{attr_key} is a non standardized attribute of {object_or_attribute.__class__.__name__}. '
                        f'The attribute will be added on the instance.',
                stacklevel=2,
                category=NonStandardAttributeWarning)
        if attribute is not None:
            yield attr_key, attribute

    def from_dict_instance(self, input_dict: DotnotationDict, model_directory: Path = None,
                           waarde_shortcut: bool = WAARDE_SHORTCUT, separator: str = SEPARATOR,
                           cardinality_indicator: str = CARDINALITY_SEPARATOR,
                           cardinality_separator: str = CARDINALITY_INDICATOR,
                           cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
                           warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False
                           ) -> OTLObject:
        if self.separator is not None:
            separator = self.separator
        if self.waarde_shortcut is not None:
            waarde_shortcut = self.waarde_shortcut
        if self.cardinality_indicator is not None:
            cardinality_indicator = self.cardinality_indicator
        if self.cardinality_separator is not None:
            cardinality_separator = self.cardinality_separator

        return self.from_dict(input_dict=input_dict, model_directory=model_directory,
                                 waarde_shortcut=waarde_shortcut,
                              separator=separator, cardinality_indicator=cardinality_indicator, cast_list=cast_list,
                              cardinality_separator=cardinality_separator, cast_datetime=cast_datetime,
                              allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                              warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)

    async def from_dict_instance_async(self, input_dict: DotnotationDict, model_directory: Path = None,
                           waarde_shortcut: bool = WAARDE_SHORTCUT, separator: str = SEPARATOR,
                           cardinality_indicator: str = CARDINALITY_SEPARATOR,
                           cardinality_separator: str = CARDINALITY_INDICATOR,
                           cast_datetime: bool = False, allow_non_otl_conform_attributes: bool = True,
                           warn_for_non_otl_conform_attributes: bool = True, cast_list: bool = False
                           ) -> OTLObject:
        if self.separator is not None:
            separator = self.separator
        if self.waarde_shortcut is not None:
            waarde_shortcut = self.waarde_shortcut
        if self.cardinality_indicator is not None:
            cardinality_indicator = self.cardinality_indicator
        if self.cardinality_separator is not None:
            cardinality_separator = self.cardinality_separator

        return await self.from_dict_async(input_dict=input_dict, model_directory=model_directory,
                                 waarde_shortcut=waarde_shortcut,
                              separator=separator, cardinality_indicator=cardinality_indicator, cast_list=cast_list,
                              cardinality_separator=cardinality_separator, cast_datetime=cast_datetime,
                              allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                              warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)

    @classmethod
    def from_dict(cls, input_dict: DotnotationDict, model_directory: Path = None,
                  cast_list: bool = False, cast_datetime: bool = False,
                  allow_non_otl_conform_attributes: bool = True, warn_for_non_otl_conform_attributes: bool = True,
                  waarde_shortcut: bool = WAARDE_SHORTCUT,
                  separator: str = SEPARATOR,
                  cardinality_indicator: str = CARDINALITY_INDICATOR,
                  cardinality_separator: str = CARDINALITY_SEPARATOR,
                  combine_errors: bool = False
                  ) -> OTLObject:
        type_uri = input_dict.get('typeURI')
        if type_uri is None:
            raise ValueError('typeURI is None. Add a valid typeURI to the input dictionary.')

        if model_directory is None:
            otl_object_file = inspect.getfile(OTLObject)
            model_directory = Path(otl_object_file).parent.parent.parent

        try:
            o = dynamic_create_instance_from_uri(str(type_uri), model_directory=model_directory)
        except TypeError as e:
            raise ValueError('typeURI is invalid. Add a valid typeURI to the input dictionary.') from e

        def _set_attributes_from_dict(items, obj, error_collector=None):
            for k, v in items:
                if v is None:
                    continue
                if k is None:  # v is not None!
                    raise MissingHeaderError(f'Missing a header for value {v}')
                if k == 'typeURI':
                    continue
                if k.startswith('_'):
                    raise ValueError(f'{k} is a non standardized attribute of {obj.__class__.__name__}. '
                                     f'While this is supported, the key can not start with "_".')
                try:
                    cls.set_attribute_by_dotnotation(
                        obj, dotnotation=k, value=v, separator=separator, cardinality_indicator=cardinality_indicator,
                        waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator,
                        cast_datetime=cast_datetime, cast_list=cast_list,
                        allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                        warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)
                except Exception as e:
                    allowed_names = {
                        'ValueError',
                        'CouldNotConvertToCorrectTypeError',
                        'UnionTypeError',
                        'InvalidOptionError',
                        'RemovedOptionError',
                        'WrongGeometryTypeError',
                    }
                    if e.__class__.__name__ in allowed_names:
                        if error_collector is not None:
                            attr_error = OTLAttributeError(
                                message=e.args[0], attribute_dotnotation=k, attribute_value=v, orig_exception=e
                            )
                            error_collector.add_exception(attr_error)
                        else:
                            raise
                    else:
                        raise

        if not combine_errors:
            _set_attributes_from_dict(input_dict.items(), o)
            return o

        combined_error = MultipleAttributeError(
            f'At least one error occurred while converting from dict to an instance of {type_uri}, see attribute exceptions for details.')
        _set_attributes_from_dict(input_dict.items(), o, error_collector=combined_error)
        if combined_error.exceptions:
            raise combined_error
        return o


    @classmethod
    async def from_dict_async(cls, input_dict: DotnotationDict, model_directory: Path = None,
                        cast_list: bool = False, cast_datetime: bool = False,
                        allow_non_otl_conform_attributes: bool = True, warn_for_non_otl_conform_attributes: bool = True,
                        waarde_shortcut: bool = WAARDE_SHORTCUT,
                        separator: str = SEPARATOR,
                        cardinality_indicator: str = CARDINALITY_INDICATOR,
                        cardinality_separator: str = CARDINALITY_SEPARATOR,
                        combine_errors: bool = False
                        ) -> OTLObject:
        type_uri = input_dict.get('typeURI')
        if type_uri is None:
            raise ValueError('typeURI is None. Add a valid typeURI to the input dictionary.')

        if model_directory is None:
            otl_object_file = inspect.getfile(OTLObject)
            model_directory = Path(otl_object_file).parent.parent.parent

        try:
            await sleep(0)
            o = dynamic_create_instance_from_uri(str(type_uri), model_directory=model_directory)
        except TypeError as e:
            raise ValueError('typeURI is invalid. Add a valid typeURI to the input dictionary.') from e

        async def _set_attributes_from_dict_async(items, obj, error_collector=None):
            for k, v in items:
                if v is None:
                    continue
                if k is None:  # v is not None!
                    raise MissingHeaderError(f'Missing a header for value {v}')
                if k == 'typeURI':
                    continue
                await sleep(0)
                if k.startswith('_'):
                    raise ValueError(f'{k} is a non standardized attribute of {obj.__class__.__name__}. '
                                     f'While this is supported, the key can not start with "_".')
                try:
                    cls.set_attribute_by_dotnotation(
                        obj, dotnotation=k, value=v, separator=separator, cardinality_indicator=cardinality_indicator,
                        waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator,
                        cast_datetime=cast_datetime, cast_list=cast_list,
                        allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                        warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)
                except (ValueError, CouldNotConvertToCorrectTypeError, UnionTypeError, RemovedOptionError,
                        WrongGeometryTypeError,) as e:
                    if error_collector is not None:
                        attr_error = OTLAttributeError(message=e.args[0], attribute_dotnotation=k, attribute_value=v,
                                                       orig_exception=e)
                        error_collector.add_exception(attr_error)
                    else:
                        raise

        if not combine_errors:
            await _set_attributes_from_dict_async(input_dict.items(), o)
            return o

        combined_error = MultipleAttributeError(
            f'At least one error occurred while converting from dict to an instance of {type_uri}, see attribute exceptions for details.')
        await _set_attributes_from_dict_async(input_dict.items(), o, error_collector=combined_error)
        if combined_error.exceptions:
            raise combined_error
        return o

    @classmethod
    def set_attribute_by_dotnotation(cls, object_or_attribute: OTLObject | OTLAttribuut,
                                     dotnotation: str, value: object,
                                     separator: str = SEPARATOR, cardinality_indicator: str = CARDINALITY_INDICATOR,
                                     waarde_shortcut: bool = WAARDE_SHORTCUT,
                                     cardinality_separator: str = CARDINALITY_SEPARATOR,
                                     cast_datetime: bool = False,
                                     cast_list: bool = False,
                                     allow_non_otl_conform_attributes: bool = True,
                                     warn_for_non_otl_conform_attributes: bool = True):
        if dotnotation.count(cardinality_indicator) > 1:
            raise DotnotationListOfListError("can't use dotnotation for lists of lists")

        if dotnotation.startswith('_'):
            raise ValueError(
                f'{dotnotation} is a non standardized attribute of {object_or_attribute.__class__.__name__}. '
                f'While this is supported, the key can not start with "_".')

        if separator not in dotnotation:
            cardinality = False
            if dotnotation.endswith(cardinality_indicator):
                dotnotation = dotnotation[:-2]
                cardinality = True

            attribute = get_attribute_by_name(object_or_attribute, dotnotation)
            if attribute is None:
                if not allow_non_otl_conform_attributes:
                    raise ValueError(
                        f'{dotnotation} is a non standardized attribute of {object_or_attribute.__class__.__name__}. '
                        f'If you want to allow this, set allow_non_otl_conform_attributes to True.')
                if warn_for_non_otl_conform_attributes:
                    warnings.warn(
                        message=f'{dotnotation} is a non standardized attribute of '
                                f'{object_or_attribute.__class__.__name__}. '
                                f'The attribute will be added on the instance.',
                        stacklevel=2,
                        category=NonStandardAttributeWarning)
                setattr(object_or_attribute, dotnotation, value)
                return
            if cardinality and cast_list:
                if value == '88888888':
                    attribute.clear_value()
                    return
                if isinstance(value, str):
                    value = [attribute.field.convert_to_correct_type(v, log_warnings=False)
                             for v in str(value).split(cardinality_separator)]
                elif isinstance(value, list):
                    value = [attribute.field.convert_to_correct_type(v, log_warnings=False)
                             for v in value]
                else:
                    value = [value]

            if attribute.field.waarde_shortcut_applicable and waarde_shortcut:
                if cardinality:
                    for index, v in enumerate(value):
                        if attribute.waarde is None or len(attribute.waarde) <= index:
                            attribute.add_empty_value()
                        if cast_list:
                            v = attribute.waarde[index]._waarde.field.convert_to_correct_type(v, log_warnings=False)
                        cls.set_attribute_by_dotnotation(
                            attribute.waarde[index], dotnotation='waarde', value=v,
                            cast_datetime=cast_datetime, cast_list=cast_list,
                            separator=separator, cardinality_indicator=cardinality_indicator,
                            waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator)
                else:
                    if attribute.waarde is None:
                        attribute.add_empty_value()
                    cls.set_attribute_by_dotnotation(
                        attribute.waarde, dotnotation='waarde', value=value,
                        cast_datetime=cast_datetime, cast_list=cast_list,
                        separator=separator, cardinality_indicator=cardinality_indicator,
                        waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator)
            else:
                if (cast_datetime and attribute.field.is_otl_field and 
                        attribute.field.native_type in {time, datetime, date}):
                    value = attribute.field.convert_to_correct_type(value, log_warnings=False)
                elif hasattr(attribute.field, 'options'):
                    if cardinality and value != '88888888':
                        value = [str(v) for v in value]
                    else:
                        value = str(value)
                attribute.set_waarde(value)
            return

        first, rest = dotnotation.split(separator, 1)
        cardinality = False
        if first.endswith(cardinality_indicator):
            first = first[:-2]
            cardinality = True
        attribute = get_attribute_by_name(object_or_attribute, first)
        if attribute is None:
            raise ValueError(f'{first} is not an attribute of {object_or_attribute.__class__.__name__}.')

        if cardinality:
            if cast_list:
                last_attribute = DotnotationHelper.get_attribute_by_dotnotation(
                    instance_or_attribute=object_or_attribute, dotnotation=dotnotation, separator=separator,
                    waarde_shortcut=waarde_shortcut, cardinality_indicator=cardinality_indicator)
                value = [last_attribute.field.convert_to_correct_type(v, log_warnings=False)
                         for v in str(value).split(cardinality_separator)]
            for index, v in enumerate(value):
                if attribute.waarde is None or len(attribute.waarde) <= index:
                    attribute.add_empty_value()
                cls.set_attribute_by_dotnotation(
                    attribute.waarde[index], dotnotation=rest, value=v,
                    cast_datetime=cast_datetime, cast_list=cast_list,
                    separator=separator, cardinality_indicator=cardinality_indicator,
                    waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator)
            return

        if attribute.waarde is None:
            attribute.add_empty_value()
        cls.set_attribute_by_dotnotation(attribute.waarde, dotnotation=rest, value=value, separator=separator,
                                         cast_datetime=cast_datetime, cast_list=cast_list,
                                         cardinality_indicator=cardinality_indicator,
                                         waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator)
        # if value == '':
        #     value = None
