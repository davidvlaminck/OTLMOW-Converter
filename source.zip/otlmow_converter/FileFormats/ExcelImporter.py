import logging
import os
import sys
import traceback
import warnings
from asyncio import sleep
from pathlib import Path
import openpyxl
from otlmow_model.OtlmowModel.BaseClasses.OTLObject import dynamic_create_instance_from_uri
from otlmow_model.OtlmowModel.Exceptions.NonStandardAttributeWarning import NonStandardAttributeWarning
from otlmow_converter.AbstractImporter import AbstractImporter
from otlmow_converter.DotnotationHelper import DotnotationHelper
from otlmow_converter.Exceptions.BadLinesInExcelError import BadLinesInExcelError
from otlmow_converter.Exceptions.DotnotationIncorrectError import DotnotationIncorrectError
from otlmow_converter.Exceptions.DotnotationListOfListError import DotnotationListOfListError
from otlmow_converter.Exceptions.ExceptionsGroup import ExceptionsGroup
from otlmow_converter.Exceptions.InvalidColumnNamesInExcelTabError import InvalidColumnNamesInExcelTabError
from otlmow_converter.Exceptions.MissingHeaderError import MissingHeaderError
from otlmow_converter.Exceptions.NoTypeUriInExcelTabError import NoTypeUriInExcelTabError
from otlmow_converter.Exceptions.NoTypeUriInTableError import NoTypeUriInTableError
from otlmow_converter.Exceptions.TypeUriNotInFirstRowError import TypeUriNotInFirstRowError
from otlmow_converter.Exceptions.UnknownExcelError import UnknownExcelError
from otlmow_converter.FileFormats.DotnotationTableConverter import DotnotationTableConverter
from otlmow_converter.SettingsManager import GlobalVariables, load_settings

load_settings()

xlsx_settings = GlobalVariables.settings['formats']['xlsx']
xlsx_dotnotation_settings = xlsx_settings['dotnotation']
SEPARATOR = xlsx_dotnotation_settings['separator']
CARDINALITY_SEPARATOR = xlsx_dotnotation_settings['cardinality_separator']
CARDINALITY_INDICATOR = xlsx_dotnotation_settings['cardinality_indicator']
WAARDE_SHORTCUT = xlsx_dotnotation_settings['waarde_shortcut']
CAST_LIST = xlsx_settings['cast_list']
CAST_DATETIME = xlsx_settings['cast_datetime']
ALLOW_NON_OTL_CONFORM_ATTRIBUTES = xlsx_settings['allow_non_otl_conform_attributes']
WARN_FOR_NON_OTL_CONFORM_ATTRIBUTES = xlsx_settings['warn_for_non_otl_conform_attributes']
IGNORE_X_COLUMNS = xlsx_settings['ignore_x_columns']


class ExcelImporter(AbstractImporter):
    @classmethod
    def to_objects(cls, filepath: Path = None, **kwargs) -> list:
        if not os.path.isfile(filepath):
            raise FileNotFoundError(f'Could not load the file at: {filepath}')

        separator = kwargs.get('separator', SEPARATOR)
        cardinality_indicator = kwargs.get('cardinality_indicator', CARDINALITY_INDICATOR)
        cardinality_separator = kwargs.get('cardinality_separator', CARDINALITY_SEPARATOR)
        waarde_shortcut = kwargs.get('waarde_shortcut', WAARDE_SHORTCUT)
        cast_list = kwargs.get('cast_list', CAST_LIST)
        cast_datetime = kwargs.get('cast_datetime', CAST_DATETIME)
        allow_non_otl_conform_attributes = kwargs.get('allow_non_otl_conform_attributes',
                                                      ALLOW_NON_OTL_CONFORM_ATTRIBUTES)
        warn_for_non_otl_conform_attributes = kwargs.get('warn_for_non_otl_conform_attributes',
                                                          WARN_FOR_NON_OTL_CONFORM_ATTRIBUTES)
        ignore_X_columns = kwargs.get('ignore_X_columns', IGNORE_X_COLUMNS)

        model_directory = None
        if kwargs is not None and 'model_directory' in kwargs:
            model_directory = kwargs['model_directory']

        data = cls.get_data_dict_from_file_path(filepath=filepath)
        if ignore_X_columns:
            data = {sheet: cls._filter_x_columns(sheet_data) for sheet, sheet_data in data.items()}

        list_of_objects = []
        exception_group = ExceptionsGroup(message=f'Failed to create objects from Excel file {filepath}')
        for sheet, sheet_data in data.items():
            try:
                if len(sheet_data) == 0:
                    if sheet_data == []:
                        continue
                    raise NoTypeUriInExcelTabError(
                        message=f'Could not find typeURI within 5 rows in Excel tab {sheet} in file {filepath.name}',
                        file_path=filepath, tab=sheet)
                if len(sheet_data) == 1:
                    # means there is a header but no data
                    continue
                headers = sheet_data[0]
                type_uri_index = cls.get_index_of_typeURI_column_in_sheet(
                    filepath=filepath, sheet=sheet, headers=headers, data=sheet_data)
                type_uris = []
                for row in sheet_data[1:]:
                    if type_uri_index < len(row) and row[type_uri_index] is not None:
                        uri = row[type_uri_index]
                        if uri not in type_uris:
                            type_uris.append(uri)
                fixed_headers, cardinality_errors = cls.check_headers(headers=headers, sheet=sheet, filepath=filepath,
                                          type_uris=type_uris, sheet_data=sheet_data,
                                          type_uri_index=type_uri_index, model_directory=model_directory,
                                          cardinality_indicator=cardinality_indicator, waarde_shortcut=waarde_shortcut,
                                          separator=separator,
                                          allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                                          warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)

                if cardinality_errors:
                    for err in cardinality_errors:
                        exception_group.add_exception(err)
                    continue

                # Replace headers with fixed headers
                sheet_data[0] = fixed_headers

                # Split cardinality columns in data rows
                sheet_data = cls._split_cardinality_columns(sheet_data, fixed_headers, cardinality_separator, cardinality_indicator)

                list_of_dicts = DotnotationTableConverter.transform_2d_sequence_to_list_of_dicts(
                    two_d_sequence=sheet_data, empty_string_equals_none=True)
                list_of_objects.extend(DotnotationTableConverter.get_data_from_table(
                    table_data=list_of_dicts, model_directory=model_directory,
                    separator=separator, cardinality_indicator=cardinality_indicator,
                    waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator,
                    cast_datetime=cast_datetime, cast_list=cast_list,
                    allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                    warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes, combine_errors=True,
                    additional_header_lines=type_uri_index))
            except TypeUriNotInFirstRowError:
                exception_group.add_exception(TypeUriNotInFirstRowError(
                    message=f'The typeURI is not in the first row in file {filepath.name}.'
                            f' Please remove the excess rows',
                    file_path=filepath, tab=sheet
                ))
            except NoTypeUriInTableError:
                if sheet.title() == 'Keuzelijsten':
                    continue
                exception_group.add_exception(NoTypeUriInExcelTabError(
                    message=f'Could not find typeURI within 5 rows in the file {filepath.name} in sheet {sheet}',
                    file_path=filepath, tab=sheet
                ))
            except MissingHeaderError as ex:
                exception_group.add_exception(MissingHeaderError(
                    message=f'{ex.args[0]} in tab {sheet} in file {filepath.name}',
                    file_path=filepath, tab=sheet
                ))
            except BadLinesInExcelError as ex:
                ex.tab = sheet
                ex.file_path = filepath
                exception_group.add_exception(ex)
                list_of_objects.extend(ex.objects)
            except BaseException as ex:
                exc_type, exc_value, exc_tb = sys.exc_info()
                tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
                logging.error("error caught!")
                logging.error("error message: \n: " + tb)
                exception_group.add_exception(UnknownExcelError(original_exception=ex, tab=sheet))

        if len(exception_group.exceptions) > 0:
            exception_group.objects = list_of_objects
            raise exception_group

        return list_of_objects

    @classmethod
    async def to_objects_async(cls, filepath: Path = None, **kwargs) -> list:
        if not os.path.isfile(filepath):
            raise FileNotFoundError(f'Could not load the file at: {filepath}')

        separator = kwargs.get('separator', SEPARATOR)
        cardinality_indicator = kwargs.get('cardinality_indicator', CARDINALITY_INDICATOR)
        cardinality_separator = kwargs.get('cardinality_separator', CARDINALITY_SEPARATOR)
        waarde_shortcut = kwargs.get('waarde_shortcut', WAARDE_SHORTCUT)
        cast_list = kwargs.get('cast_list', CAST_LIST)
        cast_datetime = kwargs.get('cast_datetime', CAST_DATETIME)
        allow_non_otl_conform_attributes = kwargs.get('allow_non_otl_conform_attributes',
                                                      ALLOW_NON_OTL_CONFORM_ATTRIBUTES)
        warn_for_non_otl_conform_attributes = kwargs.get('warn_for_non_otl_conform_attributes',
                                                          WARN_FOR_NON_OTL_CONFORM_ATTRIBUTES)
        ignore_X_columns = kwargs.get('ignore_X_columns', IGNORE_X_COLUMNS)

        model_directory = None
        if kwargs is not None and 'model_directory' in kwargs:
            model_directory = kwargs['model_directory']

        data = await cls.get_data_dict_from_file_path_async(filepath=filepath)
        if ignore_X_columns:
            data = {sheet: cls._filter_x_columns(sheet_data) for sheet, sheet_data in data.items()}

        list_of_objects = []
        exception_group = ExceptionsGroup(message=f'Failed to create objects from Excel file {filepath}')
        for sheet, sheet_data in data.items():
            try:
                await sleep(0)
                if len(sheet_data) == 0:
                    if sheet_data == []:
                        continue
                    raise NoTypeUriInExcelTabError(
                        message=f'Could not find typeURI within 5 rows in Excel tab {sheet} in file {filepath.name}',
                        file_path=filepath, tab=sheet)
                if len(sheet_data) == 1:
                    # means there is a header but no data
                    continue
                headers = sheet_data[0]
                type_uri_index = cls.get_index_of_typeURI_column_in_sheet(
                    filepath=filepath, sheet=sheet, headers=headers, data=sheet_data)
                type_uris = []
                for row in sheet_data[1:]:
                    if type_uri_index < len(row) and row[type_uri_index] is not None:
                        uri = row[type_uri_index]
                        if uri not in type_uris:
                            type_uris.append(uri)
                fixed_headers, cardinality_errors = await cls.check_headers_async(
                    headers=headers, sheet=sheet, filepath=filepath, type_uris=type_uris, sheet_data=sheet_data,
                    type_uri_index=type_uri_index, model_directory=model_directory,
                    cardinality_indicator=cardinality_indicator,
                    waarde_shortcut=waarde_shortcut, separator=separator,
                    allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                    warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes)

                if cardinality_errors:
                    for err in cardinality_errors:
                        exception_group.add_exception(err)
                    continue

                # Replace headers with fixed headers
                sheet_data[0] = fixed_headers

                # Split cardinality columns in data rows
                sheet_data = cls._split_cardinality_columns(sheet_data, fixed_headers, cardinality_separator, cardinality_indicator)

                list_of_dicts = await DotnotationTableConverter.transform_2d_sequence_to_list_of_dicts_async(
                    two_d_sequence=sheet_data, empty_string_equals_none=True)
                obj = await DotnotationTableConverter.get_data_from_table_async(
                    table_data=list_of_dicts, model_directory=model_directory,
                    separator=separator, cardinality_indicator=cardinality_indicator,
                    waarde_shortcut=waarde_shortcut, cardinality_separator=cardinality_separator,
                    cast_datetime=cast_datetime, cast_list=cast_list,
                    allow_non_otl_conform_attributes=allow_non_otl_conform_attributes,
                    warn_for_non_otl_conform_attributes=warn_for_non_otl_conform_attributes, combine_errors=True,
                    additional_header_lines=type_uri_index)
                list_of_objects.extend(obj)
            except TypeUriNotInFirstRowError:
                exception_group.add_exception(TypeUriNotInFirstRowError(
                    message=f'The typeURI is not in the first row in file {filepath.name}.'
                            f' Please remove the excess rows',
                    file_path=filepath, tab=sheet
                ))
            except NoTypeUriInTableError:
                exception_group.add_exception(NoTypeUriInExcelTabError(
                    message=f'Could not find typeURI within 5 rows in the file {filepath.name}',
                    file_path=filepath, tab=sheet
                ))
            except MissingHeaderError as ex:
                exception_group.add_exception(MissingHeaderError(
                    message=f'{ex.args[0]} in tab {sheet} in file {filepath.name}',
                    file_path=filepath, tab=sheet
                ))
            except BadLinesInExcelError as ex:
                ex.tab = sheet
                ex.file_path = filepath
                exception_group.add_exception(ex)
                list_of_objects.extend(ex.objects)
            except BaseException as ex:
                exc_type, exc_value, exc_tb = sys.exc_info()
                tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
                logging.error("error caught!")
                logging.error("error message: \n: " + tb)
                exception_group.add_exception(UnknownExcelError(original_exception=ex, tab=sheet))

        if len(exception_group.exceptions) > 0:
            exception_group.objects = list_of_objects
            raise exception_group

        return list_of_objects

    @classmethod
    def get_data_dict_from_file_path(cls, filepath) -> dict[str, list[list]]:
        data = {}
        book = openpyxl.load_workbook(filepath, data_only=True)

        for sheet in book.worksheets:
            sheet_name = sheet.title
            data[sheet_name] = []
            for row in sheet.rows:
                row_data = []
                all_none = True
                for cell in row:
                    if cell.value in {'True', 'TRUE', 'False', 'FALSE'}:
                        row_data.append(cell.value.lower() == 'true')
                        all_none = False
                    else:
                        row_data.append(cell.value)
                        if all_none and cell.value is not None:
                            all_none = False

                # check if row_data contains all None values
                if all_none:
                    continue
                data[sheet_name].append(row_data)

        book.close()
        return data

    @classmethod
    async def get_data_dict_from_file_path_async(cls, filepath) -> dict[str, list[list]]:
        data = {}
        await sleep(0)
        book = openpyxl.load_workbook(filepath, data_only=True)

        for sheet in book.worksheets:
            sheet_name = sheet.title
            data[sheet_name] = []
            for row in sheet.rows:
                row_data = []
                all_none = True
                for cell in row:
                    await sleep(0)
                    if cell.value in {'True', 'TRUE', 'False', 'FALSE'}:
                        row_data.append(cell.value.lower() == 'true')
                        all_none = False
                    else:
                        row_data.append(cell.value)
                        if all_none and cell.value is not None:
                            all_none = False

                # check if row_data contains all None values
                if all_none:
                    continue
                data[sheet_name].append(row_data)

        book.close()
        return data

    @staticmethod
    def _filter_x_columns(sheet_data: list[list]) -> list[list]:
        if not sheet_data or not sheet_data[0]:
            return sheet_data
        headers = sheet_data[0]
        x_indices = {i for i, h in enumerate(headers) if h is not None and str(h).startswith('X_')}
        if not x_indices:
            return sheet_data
        return [[val for i, val in enumerate(row) if i not in x_indices] for row in sheet_data]

    @classmethod
    def _split_cardinality_columns(cls, sheet_data: list[list], fixed_headers: list[str], cardinality_separator: str, cardinality_indicator: str) -> list[list]:
        """Split cardinality columns in data rows based on fixed headers with the configured cardinality indicator."""
        if len(sheet_data) <= 1:
            return sheet_data
        
        headers = sheet_data[0]
        # Find columns that have cardinality indicator
        cardinality_indices = {i: header for i, header in enumerate(headers) if header is not None and cardinality_indicator in header}
        
        if not cardinality_indices:
            return sheet_data
        
        result = [headers]
        for row in sheet_data[1:]:
            new_row = list(row)
            for col_idx, header in cardinality_indices.items():
                if col_idx < len(new_row) and new_row[col_idx] is not None and new_row[col_idx] != '':
                    value = str(new_row[col_idx])
                    if value == '88888888':
                        # List clearing marker must stay scalar so OTLAttribuut.set_waarde
                        # recognizes it as a clear operation rather than a list value.
                        new_row[col_idx] = value
                    elif cardinality_separator in value:
                        new_row[col_idx] = value.split(cardinality_separator)
                    else:
                        new_row[col_idx] = [value]
            result.append(new_row)
        return result

    @classmethod
    def get_index_of_typeURI_column_in_sheet(cls, filepath: Path, sheet: str,  headers: list[str],
                                             data: list[list[str]]) -> int:
        try:
            type_index = headers.index('typeURI')
        except ValueError:
            type_index = -1
        if type_index == -1:
            for row in data[1:5]:
                try:
                    type_index = row.index('typeURI')
                except ValueError:
                    type_index = -1
                if type_index != -1:
                    break
            if type_index == -1:
                raise NoTypeUriInExcelTabError(
                    message=f'Could not find typeURI within 5 rows in Excel tab {sheet} in file {filepath.name}',
                    file_path=filepath, tab=sheet)
            else:
                raise TypeUriNotInFirstRowError(
                    message=f'The typeURI is not in the first row in Excel tab {sheet} in file {filepath.name}.'
                            f' Please remove the excess rows', file_path=filepath, tab=sheet)
        return type_index

    @staticmethod
    def check_headers(headers: list[str], sheet: str, filepath: Path, type_uris: list[str], sheet_data: list[list],
                      type_uri_index: int, model_directory: Path,
                      cardinality_indicator: str = CARDINALITY_INDICATOR, waarde_shortcut: bool = WAARDE_SHORTCUT,
                      separator: str = SEPARATOR,
                      allow_non_otl_conform_attributes: bool = ALLOW_NON_OTL_CONFORM_ATTRIBUTES,
                      warn_for_non_otl_conform_attributes: bool = WARN_FOR_NON_OTL_CONFORM_ATTRIBUTES
                      ) -> tuple[list[str], list[DotnotationIncorrectError]]:
        instances = {uri: dynamic_create_instance_from_uri(uri, model_directory=model_directory) for uri in type_uris}
        bad_columns = []
        fixed_headers = []
        cardinality_errors = []

        # For each column index, determine which type URIs have non-empty data in that column.
        # A header is only validated against types that actually populate the column,
        # so a column used by one type does not fail validation for another type.
        types_with_data_per_column = {}
        for col_idx in range(len(headers)):
            types_with_data = set()
            for row in sheet_data[1:]:
                if col_idx < len(row) and row[col_idx] not in (None, ''):
                    if 0 <= type_uri_index < len(row):
                        row_type = row[type_uri_index]
                        if row_type is not None:
                            types_with_data.add(row_type)
            types_with_data_per_column[col_idx] = types_with_data

        for col_idx, header in enumerate(headers):
            if header == 'typeURI':
                fixed_headers.append(header)
                continue
            if header in ['bron.typeURI', 'doel.typeURI']:
                fixed_headers.append(header)
                continue
            if header is None:
                fixed_headers.append(header)
                continue
            header = str(header)
            if header.startswith('[DEPRECATED] '):
                bad_columns.append(header)
                fixed_headers.append(header)
                continue

            # Check for list of lists (multiple cardinality indicators) before processing
            if header.count(cardinality_indicator) > 1:
                bad_columns.append(header)
                fixed_headers.append(header)
                continue

            # Only validate against types that have data in this column
            types_with_data = types_with_data_per_column.get(col_idx, set())
            relevant_instances = [instances[uri] for uri in type_uris if uri in types_with_data]
            if not relevant_instances:
                # No type populates this column - nothing to validate
                fixed_headers.append(header)
                continue

            # Check cardinality correctness against the types that populate this column
            header_without_indicator = header.replace(cardinality_indicator, '')
            has_cardinality_in_header = cardinality_indicator in header
            fixed_header = header
            for instance in relevant_instances:
                cardinality_positions = DotnotationHelper.get_cardinality_positions_in_path(
                    instance, header_without_indicator, separator, cardinality_indicator)
                has_cardinality_in_model = len(cardinality_positions) > 0

                if has_cardinality_in_model and not has_cardinality_in_header:
                    # Missing cardinality indicator
                    if len(cardinality_positions) > 1:
                        # Multiple cardinalities in path - this would require multiple [] indicators
                        # which is not allowed (DotnotationListOfListError)
                        error = DotnotationListOfListError(
                            f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has multiple attributes with cardinality > 1 "
                            f"at positions {cardinality_positions}. Cannot fix automatically - would require multiple "
                            f"cardinality indicators which is not allowed."
                        )
                        cardinality_errors.append(error)
                        fixed_header = header
                    else:
                        # Single cardinality - add indicator after the specific attribute
                        parts = header_without_indicator.split(separator)
                        parts[cardinality_positions[0]] = parts[cardinality_positions[0]] + cardinality_indicator
                        expected_header = separator.join(parts)
                        error = DotnotationIncorrectError(
                            message=f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has incorrect cardinality indicator. "
                                    f"Expected: '{expected_header}' (attribute at position {cardinality_positions[0]} has cardinality > 1)",
                            file_path=filepath,
                            tab=sheet,
                            header=header,
                            expected_header=expected_header
                        )
                        cardinality_errors.append(error)
                        fixed_header = expected_header
                elif not has_cardinality_in_model and has_cardinality_in_header:
                    # Extra cardinality indicator
                    expected_header = header.replace(cardinality_indicator, '')
                    error = DotnotationIncorrectError(
                        message=f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has incorrect cardinality indicator. "
                                f"Expected: '{expected_header}' (no attribute in path has cardinality > 1)",
                        file_path=filepath,
                        tab=sheet,
                        header=header,
                        expected_header=expected_header
                    )
                    cardinality_errors.append(error)
                    fixed_header = expected_header
                else:
                    fixed_header = header

            # Now validate the fixed header against the types that populate this column
            for instance in relevant_instances:
                try:
                    DotnotationHelper.get_attribute_by_dotnotation(
                        instance_or_attribute=instance, dotnotation=fixed_header, separator=separator,
                        cardinality_indicator=cardinality_indicator, waarde_shortcut=waarde_shortcut)
                except DotnotationListOfListError:
                    bad_columns.append(fixed_header)
                    break
                except AttributeError:
                    if not allow_non_otl_conform_attributes:
                        bad_columns.append(fixed_header)
                    elif warn_for_non_otl_conform_attributes:
                        warnings.warn(
                            message=f'{fixed_header} is a non standardized attribute of {type_uris[0] if type_uris else "unknown"}. '
                                    f'The attribute will be added on the instance.',
                            stacklevel=2,
                            category=NonStandardAttributeWarning)
                    break

            fixed_headers.append(fixed_header)

        if len(cardinality_errors) > 0:
            # Return accumulated cardinality errors before treating lookup
            # failures as nonconforming-column errors, so callers receive
            # the promised structured cardinality diagnostic.
            return fixed_headers, cardinality_errors

        if len(bad_columns) > 0:
            raise InvalidColumnNamesInExcelTabError(
                message=f'There are invalid column names in Excel tab {sheet} in file {filepath.name}: ' +
                ', '.join(bad_columns), tab=sheet, file_path=filepath, bad_columns=bad_columns)


        return fixed_headers, cardinality_errors

    @staticmethod
    async def check_headers_async(headers: list[str], sheet: str, filepath: Path, type_uris: list[str],
                      sheet_data: list[list], type_uri_index: int, model_directory: Path,
                      cardinality_indicator: str = CARDINALITY_INDICATOR, waarde_shortcut: bool = WAARDE_SHORTCUT,
                      separator: str = SEPARATOR,
                      allow_non_otl_conform_attributes: bool = ALLOW_NON_OTL_CONFORM_ATTRIBUTES,
                      warn_for_non_otl_conform_attributes: bool = WARN_FOR_NON_OTL_CONFORM_ATTRIBUTES
                      ) -> tuple[list[str], list[DotnotationIncorrectError]]:
        await sleep(0)
        instances = {uri: dynamic_create_instance_from_uri(uri, model_directory=model_directory) for uri in type_uris}
        bad_columns = []
        fixed_headers = []
        cardinality_errors = []

        # For each column index, determine which type URIs have non-empty data in that column.
        # A header is only validated against types that actually populate the column,
        # so a column used by one type does not fail validation for another type.
        types_with_data_per_column = {}
        for col_idx in range(len(headers)):
            types_with_data = set()
            for row in sheet_data[1:]:
                if col_idx < len(row) and row[col_idx] not in (None, ''):
                    if 0 <= type_uri_index < len(row):
                        row_type = row[type_uri_index]
                        if row_type is not None:
                            types_with_data.add(row_type)
            types_with_data_per_column[col_idx] = types_with_data

        for col_idx, header in enumerate(headers):
            await sleep(0)
            if header == 'typeURI':
                fixed_headers.append(header)
                continue
            if header in ['bron.typeURI', 'doel.typeURI']:
                fixed_headers.append(header)
                continue
            if header is None:
                fixed_headers.append(header)
                continue
            header = str(header)
            if header.startswith('[DEPRECATED] '):
                bad_columns.append(header)
                fixed_headers.append(header)
                continue

            # Check for list of lists (multiple cardinality indicators) before processing
            if header.count(cardinality_indicator) > 1:
                bad_columns.append(header)
                fixed_headers.append(header)
                continue

            # Only validate against types that have data in this column
            types_with_data = types_with_data_per_column.get(col_idx, set())
            relevant_instances = [instances[uri] for uri in type_uris if uri in types_with_data]
            if not relevant_instances:
                # No type populates this column - nothing to validate
                fixed_headers.append(header)
                continue

            # Check cardinality correctness against the types that populate this column
            header_without_indicator = header.replace(cardinality_indicator, '')
            has_cardinality_in_header = cardinality_indicator in header
            fixed_header = header
            for instance in relevant_instances:
                cardinality_positions = DotnotationHelper.get_cardinality_positions_in_path(
                    instance, header_without_indicator, separator, cardinality_indicator)
                has_cardinality_in_model = len(cardinality_positions) > 0

                if has_cardinality_in_model and not has_cardinality_in_header:
                    # Missing cardinality indicator
                    if len(cardinality_positions) > 1:
                        # Multiple cardinalities in path - this would require multiple [] indicators
                        # which is not allowed (DotnotationListOfListError)
                        err = DotnotationListOfListError(
                            f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has multiple attributes with cardinality > 1 "
                            f"at positions {cardinality_positions}. Cannot fix automatically - would require multiple "
                            f"cardinality indicators which is not allowed."
                        )
                        cardinality_errors.append(err)
                        fixed_header = header
                    else:
                        # Single cardinality - add indicator after the specific attribute
                        parts = header_without_indicator.split(separator)
                        parts[cardinality_positions[0]] = parts[cardinality_positions[0]] + cardinality_indicator
                        expected_header = separator.join(parts)
                        err = DotnotationIncorrectError(
                            message=f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has incorrect cardinality indicator. "
                                    f"Expected: '{expected_header}' (attribute at position {cardinality_positions[0]} has cardinality > 1)",
                            file_path=filepath,
                            tab=sheet,
                            header=header,
                            expected_header=expected_header
                        )
                        cardinality_errors.append(err)
                        fixed_header = expected_header
                elif not has_cardinality_in_model and has_cardinality_in_header:
                    # Extra cardinality indicator
                    expected_header = header.replace(cardinality_indicator, '')
                    err = DotnotationIncorrectError(
                        message=f"Header '{header}' in file '{filepath.name}' tab '{sheet}' has incorrect cardinality indicator. "
                                f"Expected: '{expected_header}' (no attribute in path has cardinality > 1)",
                        file_path=filepath,
                        tab=sheet,
                        header=header,
                        expected_header=expected_header
                    )
                    cardinality_errors.append(err)
                    fixed_header = expected_header
                else:
                    fixed_header = header

            # Now validate the fixed header against the types that populate this column
            for instance in relevant_instances:
                try:
                    DotnotationHelper.get_attribute_by_dotnotation(
                        instance_or_attribute=instance, dotnotation=fixed_header, separator=separator,
                        cardinality_indicator=cardinality_indicator, waarde_shortcut=waarde_shortcut)
                except DotnotationListOfListError:
                    bad_columns.append(fixed_header)
                    break
                except AttributeError:
                    if not allow_non_otl_conform_attributes:
                        bad_columns.append(fixed_header)
                    elif warn_for_non_otl_conform_attributes:
                        warnings.warn(
                            message=f'{fixed_header} is a non standardized attribute of {type_uris[0] if type_uris else "unknown"}. '
                                    f'The attribute will be added on the instance.',
                            stacklevel=2,
                            category=NonStandardAttributeWarning)
                    break

            fixed_headers.append(fixed_header)

        if len(cardinality_errors) > 0:
            # Return accumulated cardinality errors before treating lookup
            # failures as nonconforming-column errors, so callers receive
            # the promised structured cardinality diagnostic.
            return fixed_headers, cardinality_errors

        if len(bad_columns) > 0:
            raise InvalidColumnNamesInExcelTabError(
                message=f'There are invalid column names in Excel tab {sheet} in file {filepath.name}: ' +
                ', '.join(bad_columns), tab=sheet, file_path=filepath, bad_columns=bad_columns)

        return fixed_headers, cardinality_errors
