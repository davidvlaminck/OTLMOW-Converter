class InvalidExtensionError(ValueError):
    pass
